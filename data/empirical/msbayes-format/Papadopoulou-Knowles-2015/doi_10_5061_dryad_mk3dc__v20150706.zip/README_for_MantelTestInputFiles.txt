This folder contains data files for the study of Papadopoulou & Knowles (2015): "Species-specific responses to island connectivity cycles: refined models for testing phylogeographic concordance across a Mediterranean Pleistocene Aggregate Island complex"


a) Pairwise distance matrices for Mantel tests used to test for 'isolation-by-distance' and 'isolation-by-bathymetry' in 13 darkling beetle species across the Cycladic plateau

- GeogrDist: pairwise geographic distances among sampled localities
- BathRes: rescaled distances among localities calculated in Circuitscape, taking into account bathymetry and local sea-level curve
- PiXY: Above diagonal : Average number of pairwise differences between populations (PiXY) / Below diagonal    : Corrected average pairwise difference (PiXY-(PiX+PiY)/2)

b) An ASCII input file for Circuitscape, where the currently submerged shelf of the Cycladic plateau was divided into 10m-depth intervals (based on data from http://www.emodnet-bathymetry.eu), and conductance values (on a 0-100 scale) were assigned 
based on the relative time of exposure of each interval (%) during the last glacial cycle (data from Lambeck, 1996).

c) Coordinates of the sampled localities. 

Island abbreviations:
AND: Andros
ANO: Ano Koufonissi
ANT: Antiparos
DON: Donoussa
HER: Herakleia
MYK: Mykonos
NAX: Naxos
PAR: Paros
SCH: Schinoussa
SYR: Syros
TIN: Tinos
		
