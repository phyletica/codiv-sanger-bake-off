This folder contains tree files from the study of Papadopoulou & Knowles (2015): "Species-specific responses to island connectivity cycles: refined models for testing phylogeographic concordance across a Mediterranean Pleistocene Aggregate Island complex"

These are Cox1 gene trees estimated in BEAST under a lognormal uncorrelated relaxed clock, with a mean rate of 0.0168 substitutions/site/My. Four independent runs of 20 million generations were conducted for each dataset and sampled trees from all independent runs were pooled after removing a 10% burn-in and summarized on a “maximum clade credibility” tree using TreeAnnotator. 

You can open these files in FigTree (http://tree.bio.ed.ac.uk/software/figtree/).

Taxon names contain a six-digit voucher specimen code (see supplementary material) followed by a 4-letter indicating the species name and the Island where the sample comes from. See abbreviations below:


Species abbreviations used in taxon names:

Am: Ammobius rufus
Da: Dailognatha quadricollis
Dh: Dailognatha hellenica
Di: Dichomma dardanum
Er: Erodius orientalis
Es: Eutagenia sp.
Eu: Eutagenia smyrnensis
Gr: Graecopachys quadricollis
Mi: Micrositus orbicularis
Pi: Pimelia sericella
Te: Tentyria rotundata
St: Stenosis syrensis
Zo: Zophosis punctata




Island abbreviations used in taxon names:

Ad: Andros
Ti: Tinos
My: Mykonos
Sy: Syros
Na: Naxos
Pa: Paros
An: Antiparos
He: Herakleia
Sc: Schinoussa
Ao: Ano Koufonissi
Do: Donoussa
